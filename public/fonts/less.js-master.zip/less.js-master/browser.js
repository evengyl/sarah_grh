module.exports = require('./lib/less-browser');
